package com.example.attendanceapp;


import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class AttendanceResultActivity extends AppCompatActivity {

    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance_result);

        tvResult = findViewById(R.id.tvResult);

        ArrayList<String> presentStudents = getIntent().getStringArrayListExtra("present_students");

        if (presentStudents != null && !presentStudents.isEmpty()) {
            StringBuilder builder = new StringBuilder("Present Students:\n\n");
            for (String name : presentStudents) {
                builder.append(name).append("\n");
            }
            tvResult.setText(builder.toString());
        } else {
            tvResult.setText("No students present.");
        }
    }
}
