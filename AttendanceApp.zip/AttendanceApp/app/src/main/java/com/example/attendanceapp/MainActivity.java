package com.example.attendanceapp;


import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvStudents;
    private Button btnSubmit;
    private StudentAdapter adapter;
    private ArrayList<Student> studentList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvStudents = findViewById(R.id.rvStudents);
        btnSubmit = findViewById(R.id.btnSubmit);

        // Sample students
        studentList = new ArrayList<>();
        studentList.add(new Student("Rahul"));
        studentList.add(new Student("Priya"));
        studentList.add(new Student("Aman"));
        studentList.add(new Student("Neha"));
        studentList.add(new Student("Suresh"));

        adapter = new StudentAdapter(studentList);
        rvStudents.setLayoutManager(new LinearLayoutManager(this));
        rvStudents.setAdapter(adapter);

        btnSubmit.setOnClickListener(v -> {
            ArrayList<String> presentStudents = new ArrayList<>();
            for (Student student : studentList) {
                if (student.isPresent()) {
                    presentStudents.add(student.getName());
                }
            }
            Intent intent = new Intent(MainActivity.this, AttendanceResultActivity.class);
            intent.putStringArrayListExtra("present_students", presentStudents);
            startActivity(intent);
        });
    }
}
